* Hearing Aid CNN Output
* Python CNN -> Analog Front End

V_CNN_OUT cnn_out 0 PWL(
+ 0.000000e+00 1.126659
+ 1.000000e-08 0.808317
+ 2.000000e-08 0.400000
)
